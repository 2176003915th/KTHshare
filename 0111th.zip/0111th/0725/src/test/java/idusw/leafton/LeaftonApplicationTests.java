package idusw.leafton;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeaftonApplicationTests {

    @Test
    void contextLoads() {
    }

}

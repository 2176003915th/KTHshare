package idusw.leafton;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeaftonApplication {

    public static void main(String[] args) {
        SpringApplication.run(LeaftonApplication.class, args);
    }

}

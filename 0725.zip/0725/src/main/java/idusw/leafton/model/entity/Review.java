package idusw.leafton.model.entity;

import idusw.leafton.model.DTO.ReviewDTO;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "review")
public class Review {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "reviewId")
    private Long reviewId;

    @ManyToOne
    @JoinColumn(name = "productId")
    private Product product;

    @Column
    private int rating;

    @Column
    private String content;

    @Column
    private LocalDateTime registDate;

    public static Review toReviewEntity(ReviewDTO reviewDTO){
        Review review = new Review();

        review.setReviewId(reviewDTO.getReviewId());
        review.setProduct(reviewDTO.getProduct());
        review.setRating(reviewDTO.getRating());
        review.setContent(reviewDTO.getContent());
        review.setRegistDate(reviewDTO.getRegistDate());

        return review;
    }
}

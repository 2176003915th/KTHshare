package idusw.leafton.model.entity;

import idusw.leafton.model.DTO.CartDTO;
import jakarta.persistence.Entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name="cart")
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cartId")
    private Long cartId;

    @OneToOne
    @JoinColumn (name = "memberid") //fk 지정
    private Member member;

    public static Cart toCartEntity(CartDTO cartDTO){
        Cart cart = new Cart();
        cart.setCartId(cartDTO.getCartId());
        cart.setMember(cartDTO.getMember());

        return cart;
    }
}
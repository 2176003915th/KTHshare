package idusw.leafton.model.service;

import idusw.leafton.model.DTO.ProductDTO;
import idusw.leafton.model.DTO.ReviewDTO;
import idusw.leafton.model.entity.Product;
import idusw.leafton.model.entity.Review;
import idusw.leafton.model.repository.ProductRepository;
import idusw.leafton.model.repository.ReviewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


@Service
@RequiredArgsConstructor
public class ReviewServiceImpl implements ReviewService{

    private final ReviewRepository reviewRepository;
    private final ProductService productService;
    @Override
    public List<ReviewDTO> viewAllReviews(Long productId) {
        Product product = productService.getProductById(productId); // 객체지향 컬럼
        List<Review> reviewList = reviewRepository.findAllByProduct(product);
        List<ReviewDTO> reviewDTOList = new ArrayList<>();
        for(Review review: reviewList) {
            reviewDTOList.add(ReviewDTO.toReviewDTO(review));
        }
        return reviewDTOList;
    }

    @Override
    public ReviewDTO insertReview(Long productId, String reviewContent) {
        Product product = productService.getProductById(productId);
        Review review = new Review(); //받은 DTO에서 entity로 변환
        review.setProduct(product);
        review.setContent(reviewContent);
        review.setRegistDate(LocalDateTime.now());
        Review savedReview = reviewRepository.save(review); //변환된 결과값 저장

        ReviewDTO savedReviewDTO = new ReviewDTO(); // 다시 변환된 결과를 DTO로 변환함
        savedReviewDTO.setProduct(savedReview.getProduct());
        savedReviewDTO.setContent(savedReview.getContent());
        savedReviewDTO.setRegistDate(LocalDateTime.now());
        return savedReviewDTO;
    }

}

package idusw.leafton.model.service;

import idusw.leafton.model.DTO.ProductDTO;
import idusw.leafton.model.entity.Product;
import org.springframework.stereotype.Service;

import java.util.List;

public interface ProductService { //ProductService 구현도
    public List<ProductDTO> viewAllProducts(); //List

    ProductDTO viewDetailProduct(Long productId);

    Product getProductById(Long productId); // controller 에서 productId를 하나는 Long으로 자신 product 사용, 하나는 객체지향으로 사용을 동시에할때
}